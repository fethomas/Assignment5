data from here: https://github.com/cocoxu/Shakespeare
